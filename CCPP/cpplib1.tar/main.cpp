/*
See https://computer.howstuffworks.com/c15.htm

For C:
gcc -c -g myutil.c
gcc -c -g main.c
gcc -o main main.o myutil.o
main

For C++:
g++ -c -g main.cpp
g++ -c -g myutil.cpp
g++ -o main.exe main.o myutil.o
main
*/

#include <iostream>
#include "myutil.h"

int main()
{
    std::cout << "Hello new world of C++!\n";

    int newyear;
    newyear = aloha(2019);
    std::cout << "newyear = " << newyear;

    return 0;
}
