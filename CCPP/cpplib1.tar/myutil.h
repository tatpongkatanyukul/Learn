/*
src: https://computer.howstuffworks.com/c15.htm
*/

extern int aloha(int i); // does not seem to matter whether there is "extern"
//int aloha(int i);
