/* src: https://computer.howstuffworks.com/c15.htm */
/* run this first:
   gcc -c -g myutil.c
*/

#include "myutil.h"

int aloha(int i)
{
    int j = i + 1;
    return j;
}
